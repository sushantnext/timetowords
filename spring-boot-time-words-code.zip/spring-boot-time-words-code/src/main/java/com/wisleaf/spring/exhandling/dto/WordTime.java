package com.wisleaf.spring.exhandling.dto;



public class WordTime {

  int hr;
  int min;
  
  public void setHr(int hr) {
	  this.hr=hr;
  }
  
  public int getHr() {
	  return this.hr;
  }
  
  public void setMin(int min) {
	  this.min=min;
  }
  
  public int getMin() {
	  return this.min;
  }
	  
}
