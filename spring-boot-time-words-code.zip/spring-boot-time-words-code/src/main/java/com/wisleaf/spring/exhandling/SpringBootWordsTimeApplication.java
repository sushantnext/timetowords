package com.wisleaf.spring.exhandling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWordsTimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWordsTimeApplication.class, args);
	}

}
