package com.wisleaf.spring.exhandling.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wisleaf.spring.exhandling.exception.ResourceNotFoundException;

public class TimeHelper{
	
	// Print Time in words.
    public static String printWords(int h, int m)
    {
    	String timeInWords=null;
        String nums[] = { "zero", "one", "two", "three", "four",
                            "five", "six", "seven", "eight", "nine",
                            "ten", "eleven", "twelve", "thirteen",
                            "fourteen", "fifteen", "sixteen", "seventeen",
                            "eighteen", "nineteen", "twenty", "twenty one",
                            "twenty two", "twenty three", "twenty four",
                            "twenty five", "twenty six", "twenty seven",
                            "twenty eight", "twenty nine",
                        };
     
        if(h==12 && m==0) {
        	timeInWords="Its midday";
        	return timeInWords;

        }else if(h==24 && m==0) {
        	timeInWords="Its midNight";
        	return timeInWords;

        }
        if (m == 0)
            timeInWords=nums[h] + " o' clock ";
     
        else if (m == 1)
        	timeInWords="one minute past "+ nums[h];
     
        else if (m == 59)
        	timeInWords="one minute to " + nums[(h % 12) + 1];
        else if (m == 15)
            timeInWords="quarter past " + nums[h];
        else if (m == 30)
            timeInWords="half past " + nums[h];
        else if (m == 45)
        	timeInWords="quarter to " + nums[(h % 12) + 1];
        else if (m <= 30)
            timeInWords= nums[m]+" minutes past " + nums[h];
        else if (m > 30)
        	timeInWords=nums[60 - m] + " minutes to " +  nums[(h % 12) + 1];
        
        return timeInWords;
    }
     
   
    public static void main(String []args)
    {
        int h = 6;
        int m = 24;
        printWords(h, m);
    }


	
}