package com.wisleaf.spring.exhandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@RunWith(SpringRunner.class)
@SpringBootTest(
  SpringBootTest.WebEnvironment.MOCK,
  classes = Application.class)
@AutoConfigureMockMvc
class SpringBootExceptionHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
